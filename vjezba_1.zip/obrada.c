#include <stdio.h>
#include <signal.h>

#define N 6

int OZNAKA_CEKANJA[N];
int PRIORITET[N];
int TEKUCI_PRIORITET;
int sig[]={SIGABRT, SIGUSR1, SIGBUS, SIGCONT, SIGINT};


void zabrani_prekidanje(){
    int i;
    for(i=0; i<5; i++)
        sighold(sig[i]);
}

void dozvoli_prekidanje(){
   int i;
   for(i=0; i<5; i++)
      sigrelse(sig[i]);
}

void prekidna_rutina(int sig){
   int n=1;
   zabrani_prekidanje();
   switch(sig){
      case SIGABRT:
         n=1;
         printf("- X - - - -\n");
         break;
      case SIGUSR1:
         n=2;
         printf("- - X - - -\n");
         break;
      case SIGBUS:
         n=3;
         printf("- - - X - -\n");
         break;
      case SIGCONT:
         n=4;
         printf("- - - - X -\n");
         break;
      case SIGINT:
         n=5;
         printf("- - - - - X\n");
         break;
   }

   OZNAKA_CEKANJA[n]=1;
   int i, a=0;
    if (TEKUCI_PRIORITET<n){
    do {
        for (a=TEKUCI_PRIORITET+1;i<N;i++)
            if (OZNAKA_CEKANJA[i]==1)   a=i;
            if (a>0){
                        OZNAKA_CEKANJA[a]=0;
                        PRIORITET[a]=TEKUCI_PRIORITET;
                        TEKUCI_PRIORITET=a;
                        dozvoli_prekidanje;
                        obrada_prekida(a);
                        zabrani_prekidanje;
                        TEKUCI_PRIORITET=PRIORITET[a];
                }
   }while (a>0);
   }
   dozvoli_prekidanje();
}



int obrada_prekida(int i){
    sigset (SIGABRT, prekidna_rutina);
    sigset (SIGUSR1, prekidna_rutina);
    sigset (SIGBUS, prekidna_rutina);
    sigset (SIGCONT, prekidna_rutina);
    sigset (SIGINT, prekidna_rutina);

    int x=0;
    switch (i){
            case (1):
                    printf ("- P - - - -\n");
                    for (x=1;x<=5;x++){
                    printf ("- %d - - - -\n",x);
                    sleep (1);
                        }
                    printf ("- K - - - -\n");
                    break;
            case (2):
                    printf ("- - P - - -\n");
                    for (x=1;x<=5;x++){
                    printf ("- - %d - - -\n",x);
                    sleep (1);
                        }
                    printf ("- - K - - -\n");
                    break;
            case (3):
                    printf ("- - - P - -\n");
                    for (x=1;x<=5;x++){
                    printf ("- - - %d - -\n",x);
                    sleep (1);
                        }
                    printf ("- - - K - -\n");
                    break;
            case (4):
                    printf ("- - - - P -\n");
                    for (x=1;x<=5;x++){
                    printf ("- - - - %d -\n",x);
                    sleep (1);
                        }
                    printf ("- - - - K -\n");
                    break;
            case (5):
                    printf ("- - - - - P\n");
                    for (x=1;x<=5;x++){
                    printf ("- - - - - %d\n",x);
                    sleep (1);
                        }
                    printf ("- - - - - K\n");
                    break;
        }
}

int main ( void )

{

   sigset (SIGABRT, prekidna_rutina);
   sigset (SIGUSR1, prekidna_rutina);
   sigset (SIGBUS, prekidna_rutina);
   sigset (SIGCONT, prekidna_rutina);
   sigset (SIGINT, prekidna_rutina);

   printf("Proces obrade prekida, PID=%d\n", getpid());
   printf("GL S1 S2 S3 S4 S5\n");
   sleep(10);
   int broji=0;
   for (broji=0;broji<=10;broji++) {
        sleep(1);
        printf("%d - - - - -\n",broji);}
        printf ("Zavrsio osnovni program\n");
   return 0;

}
