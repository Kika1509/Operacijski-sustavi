#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <math.h>
#include <pthread.h>
#include <ctype.h>

#define BR_DRETVI 4

int pauza = 0;
int id[BR_DRETVI] = {0,1,2,3};
pthread_t dretv_id[BR_DRETVI];
unsigned long broj = 2;
unsigned long zadnji = 2;
int ZADNJI_BROJ;
int ULAZ[BR_DRETVI] = {0};
int BROJ[BR_DRETVI] = {0};

void periodicki_ispis () {
   printf("%lu\n",zadnji);
}

void nista () {
   printf ( "Nastavak rada jedne dretve\n" );
}
void postavi_pauzu () {
    int i;
   pauza = 1 - pauza;
   if( pauza == 0 ) {
      for(i=0; i<BR_DRETVI; i++)
         pthread_kill (dretv_id[i], SIGUSR1);
   }
}

void prekini () {
   printf("%lu\n",zadnji);
   exit (1);
}

int prost ( unsigned long n ) {
	unsigned long i, max;

	if ( ( n % 2 ) == 0 )
		return 0;

	max = sqrt (n) ;
	for ( i = 3; i <= max; i += 2 ){
		if ( ( n % i ) == 0 )
			return 0;
        }
	return 1;
}

void pocetak_KO(int i)
{
	int j;

	ULAZ[i] = 1;
	BROJ[i] = ZADNJI_BROJ + 1;
	ZADNJI_BROJ = BROJ[i];
	ULAZ[i] = 0;

	for (j = 0; j < BR_DRETVI; j++) {
		while (ULAZ[j] != 0) ;
		while ((BROJ[j] != 0) && (BROJ[j] < BROJ[i] || (BROJ[j] == BROJ[i] && j < i))) ;
	}
}

void kraj_KO(int i)
{
	BROJ[i] = 0;
}

void *broji (void *x) {
    sigset(SIGUSR1,nista);
    int i,broj,moj,test;
    i=*((int*)x);
   while(i<BR_DRETVI)
   {
      while ( pauza == 1 )
        pause();

      pocetak_KO (i);

      moj = broj;
      broj++;

      kraj_KO (i);

      test = prost ( moj );

      pocetak_KO (i);

      if ( (test == 1) && (moj > zadnji) )
         zadnji = moj;
      kraj_KO (i);

   }
}


int main () {

    struct itimerval t;
    int i;
  

   sigset( SIGINT, postavi_pauzu );
   sigset( SIGTERM, prekini );
   sigset ( SIGALRM, periodicki_ispis );

   t.it_value.tv_sec = 5;
   t.it_value.tv_usec = 500000;
   t.it_interval.tv_sec = 5;
   t.it_interval.tv_usec = 500000;

   setitimer ( ITIMER_REAL, &t, NULL );

   for (i=0; i<BR_DRETVI; i++ ){
      if (pthread_create(&dretv_id[i], NULL, (void * ) broji, (void * ) &id[i])) {
				printf("Nije bilo moguce stvoriti dretvu!");
				exit(1);
		}
		}

   for (i=0; i<BR_DRETVI; i++ ){
	pthread_join(dretv_id[i], NULL);
}

    return 0;

}
