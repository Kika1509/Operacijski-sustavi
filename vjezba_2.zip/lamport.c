#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>
#include <stdlib.h>

int *trazim;
int *broj;
int *stol;
int br_proc;
int br_stol;
int memtrazi;
int memstol;
int membroj;
int max;


void pocetak_KO(int i)
{
  int j;
  trazim[i] = 1;
  max=broj[0];
  for (j=0; j< br_proc; j++){
  if (broj[j] > max) max = broj[j];
    }
    broj[i]=max +1;
   trazim[i] = 0;

   for(j = 0; j < br_proc; j++){
   while (trazim[j] != 0);
   while (broj[j] != 0 && ((broj[j]) < (broj[i]) || ((broj[j]) == (broj[i]) && j < i)));
}
}

void kraj_KO(int i)
{
	broj[i] = 0;
}

void brisi()
{
	(void) shmdt((char *) broj);
	(void) shmdt((char *) trazim);
	(void) shmdt((char *) stol);
	(void) shmctl(membroj, IPC_RMID, NULL);
	(void) shmctl(memtrazi, IPC_RMID, NULL);
	(void) shmctl(memstol, IPC_RMID, NULL);
	exit (0);
}

void ispis(int i, int br_proc, int br_stol)
{
    int kojistol[br_stol];
    int biram;
    int m, s=0, z=0;

    while(s >= 0)
    {
    s=0;
    for(m=0; m<br_stol; m++){
        if(stol[m] == 0){
            kojistol[s]=m;
            s++;
            }
    }

    srand((unsigned)time(NULL));
    sleep(1);
    biram = rand() % s;
    printf("Proces %d: odabirem stol %d\n", i, (kojistol[biram]+1));

    sleep(3);

    pocetak_KO(i);

    if(stol[kojistol[biram]] == 0){
        stol[kojistol[biram]] = i;
        printf("Proces %d: rezerviram stol %d, stanje:\n", i, kojistol[biram]+1);
        z++;

    }
    else{
        printf("Proces %d: neuspjela rezervacija stola %d, stanje:\n", i, kojistol[biram]+1);
    }
    for(m=0; m<br_stol; m++)
        {
            if(stol[m]==0) printf("- ");
            else printf("%d ", stol[m]);
        }
    printf("\n");
    kraj_KO(i);
    s--;
}}

int main (int argc, char *argv[]){
    int br=0,l;
    br_proc=atoi(argv[1]);
    br_stol=atoi(argv[2]);
    sigset(SIGINT, brisi);

    int i;
    memtrazi = shmget(IPC_PRIVATE, sizeof(int) * 100, 0600);
    if (memtrazi == -1) {
		printf("Greška: Nema zajednicke memorije!\n");
		exit(1);
	}
	 membroj = shmget(IPC_PRIVATE, sizeof(int) * 100, 0600);
    if (membroj == -1) {
		printf("Greška: Nema zajednicke memorije!\n");
		exit(1);
	}
	 memstol = shmget(IPC_PRIVATE, sizeof(int) * 100, 0600);
    if (memstol == -1) {
		printf("Greška: Nema zajednicke memorije!\n");
		exit(1);
	}

    trazim = (int *) shmat(memtrazi, NULL,0);
    broj = (int *) shmat(membroj, NULL, 0);
    stol = (int *) shmat(memstol, NULL, 0);

    for (l=0; l<br_stol; l++){
        stol[br]= 0;
        }


    while (br < br_proc ) {
		switch (fork()) {
			case 0:
				ispis(br+1,br_proc, br_stol);
				exit(0);
			case -1:
				printf("Nije bilo moguce stvoriti proces!");
				exit(1);
			default:
				br++;

    }sleep(1);}

    while(br--){
    wait(NULL);}

    brisi();


    return 0;
}

