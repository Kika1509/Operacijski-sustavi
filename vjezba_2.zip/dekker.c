#include <stdio.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>


int PRAVO = 1;
int ZASTAVICA[2] = {0};

void pocetak_KO(int i, int j){
    int a;
    ZASTAVICA[i] = 1;
    while(ZASTAVICA[j] != 0){
        if(PRAVO == j){
            ZASTAVICA[i] = 0;
            while (PRAVO == j) {
                a=1;
            }
            ZASTAVICA[i] = 1;
            sleep(1);
        }

    }
    sleep(1);
}

void kraj_KO(i,j){
    PRAVO = j;
    ZASTAVICA[i] = 0;
    ZASTAVICA[j] = 1;
    sleep(1);
}

void ispis(void *l){
    int i,k,a;
    i=*((int *)l);
    if(i==0){
        for(k=1; k<=5; k++){
        pocetak_KO(i, 1);
        for(a=1; a<=5; a++){
            printf("Dretva: %d, K.O. br: %d (%d/5)\n", i+1, k, a);
            sleep(1);
        }
        kraj_KO(i, 1);
    }
    }

    else if(i==1){
        for(k=1; k<=5; k++){
            pocetak_KO(i, 0);
            for(a=1; a<=5; a++){
                printf("Dretva: %d, K.O. br: %d (%d/5)\n", i+1, k, a);
                sleep(1);
        }
        kraj_KO(i, 0);
    }

}
}

int main(){
    int i;
    pthread_t thr_id[2];
    int n[2]={1,0};

    for (i=0;i<2;i++){

        if (pthread_create(&thr_id[i], NULL, (void*) ispis, (void*)&n[i]) != 0) {
            printf("Greska u stvaranju dretve %d\n", i+1);
            exit(1);
        }

    }

    pthread_join(thr_id[0], NULL);
    pthread_join(thr_id[1], NULL);

    return 0;
}
