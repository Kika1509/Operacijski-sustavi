#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <pthread.h>

pthread_cond_t JEDAN;
pthread_cond_t NULA;
pthread_mutex_t MONITOR;

int auti=0;
int smjer_na_mostu=0;
int smjer;

void popni_se_na_most(int smjer)
{
    pthread_mutex_lock(&MONITOR);
    while(auti==3 || (smjer_na_mostu!=smjer && auti>0)){
        if (smjer==1) pthread_cond_wait(&JEDAN,&MONITOR);
            else pthread_cond_wait(&NULA,&MONITOR);
    }
    auti++;
    smjer_na_mostu=smjer;
    pthread_mutex_unlock(&MONITOR);
	}
void sidi_s_mosta(int smjer)
{
    pthread_mutex_lock(&MONITOR);
    auti--;
    if(auti==0) {
       if (smjer==1) pthread_cond_broadcast(&NULA);
        else pthread_cond_broadcast(&JEDAN);
    pthread_mutex_unlock(&MONITOR);
	}
}

void *Auto(int smjer)
{
    popni_se_na_most(smjer);
    sleep(1);
    printf("Prelazi most");
    sleep(1);
    sidi_s_mosta(smjer);
    sleep(1);
    printf("Prešao most");
}

int main(){
    int j,n;

    printf("Upisite broj auti:");
    scanf("%d",&n);

	pthread_mutex_init(&MONITOR,NULL);
    pthread_cond_init(&NULA, NULL);
    pthread_cond_init(&JEDAN, NULL);

	for(j=0;j<n;j++){
        smjer=rand()%2;
		if (pthread_create(&(j), NULL, (void*)Auto, (void*)&smjer) != 0) {
		printf("Greska pri stvaranju dretve proizvodaca!\n");
		exit(1);
		}
		else printf("Dretve stvorene");
	}
    for(j=0; j<n; j++)
		pthread_join(j, NULL);

return 0;

}



