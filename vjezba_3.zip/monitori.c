#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <pthread.h>

pthread_cond_t PRAZAN;
pthread_cond_t PUN;
pthread_mutex_t MONITOR;

int ULAZ=0, IZLAZ=0;
char M[5]={0};
int br_mjesta=5;
int proi_ceka=0,potr_ceka=0;
typedef struct{
		int id;
		char niz[20];
	}p;

 void *proizvodac (char *upis) {
    int j=0, k=-1;
    char niz[100];
    p podaci;
    int id = podaci.id;
    podaci=*((p*)upis);
    strcpy(niz,podaci.niz);
    do {
        pthread_mutex_lock(&MONITOR);
        while(br_mjesta==0){
            proi_ceka=1;
			pthread_cond_wait(&PUN,&MONITOR);
        }
        br_mjesta--;
		M[ULAZ] = niz[j];
		printf("PROIZVODAC%d -> %c\n",id+1, niz[j]);
		ULAZ = (ULAZ+1)%5;
		if(potr_ceka!=1) pthread_mutex_unlock(&MONITOR);
            else {
            potr_ceka=0;
			pthread_cond_broadcast(&PRAZAN);
			pthread_mutex_unlock(&MONITOR);
			}
        k++;
        j++;
        sleep(1);
        }while(niz[k]!='\0');
    return;
}


 void *potrosac(void *upis){
    char niz[150];
    int i=0, n=0;
    int m=*(int*)upis;

    do{
        pthread_mutex_lock(&MONITOR);
		while(br_mjesta==5){
			potr_ceka=1;
			pthread_cond_wait(&PRAZAN,&MONITOR);
		}
		if(M[IZLAZ]=='\0') n++;
            else {
                niz[i] = M[IZLAZ];
                i++;
            }
        printf("POTROSAC -> %c\n",niz[i]);
		IZLAZ=(IZLAZ +1)%5;
		br_mjesta++;
		if(proi_ceka!=1) pthread_mutex_unlock(&MONITOR);
		else{
			proi_ceka=0;
			pthread_cond_broadcast(&PUN);
			pthread_mutex_unlock(&MONITOR);
		}
    }while(n<(m-1));
    niz[i]='\0';
    printf("Primljeno je %s\n",niz);
    return;
}


int main(int argc, char *argv[]){
    int j;
    p podaci[argc-1];
    int br_proiz=argc-1;

    pthread_t proi_id[br_proiz];
	pthread_t potr_id[1];

	pthread_mutex_init(&MONITOR,NULL);
    pthread_cond_init(&PUN, NULL);
    pthread_cond_init(&PRAZAN, NULL);

	for(j=1;j<argc;j++){
		podaci[j].id=j+1;
		strcpy(podaci[j].niz,argv[j+1]);
		printf("%s",argv[j+1]);
		if (pthread_create(&proi_id[j], NULL, (void*)proizvodac, (void*)&podaci[j]) != 0) {
		printf("Greska pri stvaranju dretve proizvodaca!\n");
		exit(1);
		}
		else printf("Stvoren proizvodac");
	}
    if (pthread_create(&potr_id[1], NULL, (void*)potrosac, (void*)&argc) != 0) {
		printf("Greska pri stvaranju dretve potrosaca!\n");
		exit(1);
		}
		else printf("Stvoren potrosac");
    for(j=1; j<argc; j++)
		pthread_join(proi_id[j], NULL);
    pthread_join(potr_id[0], NULL);

return 0;

}
