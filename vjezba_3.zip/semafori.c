#include <stdio.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <signal.h>
#include <sys/shm.h>

int *ULAZ, *IZLAZ;
typedef struct{
    char M[5];
}MS;
MS *mesp;
int SemId, ID;
int br_proi;


int pisi=1;
int pun=2;
int prazan=3;


void SemGet(int n){
    SemId = semget(IPC_PRIVATE, n, 0600);
    if (SemId == -1) {
        printf("Nema semafora!\n");
        exit(1);}
}


int SemSetVal(int SemNum, int SemVal){
    return semctl(SemId, SemNum, SETVAL, &SemVal);
    }


int SemOp(int SemNum, int SemOp) {
    struct sembuf SemBuf;
    SemBuf.sem_num = SemNum;
    SemBuf.sem_op  = SemOp;
    SemBuf.sem_flg = 0;
    return semop(SemId, & SemBuf, 1);
}


void SemRemove() {
    (void) semctl(SemId, 0, IPC_RMID, 0);
}


void brisi (){
    (void) shmdt((char *) ULAZ);
    (void) shmdt((char *) IZLAZ);
    (void) shmdt((char *) mesp);
    (void) shmctl(ID, IPC_RMID, NULL);
    exit(0);
}


 void proizvodac (int i,char *niz) {
    int j=0;
    do {
        SemOp(pun,-1);
        SemOp(pisi,-1);
        mesp->M[*ULAZ]=niz[j];
        printf("Proizvodac%d -> %c \n",i,niz[j]);
        *ULAZ=(*ULAZ+1)%5;
        SemOp(pisi,1);
        SemOp(prazan,1);
        j=j+1;
        sleep(1);
        }while(niz[j]!='\0');

    SemOp(pun,-1);
    SemOp(pisi,-1);
    mesp->M[*ULAZ]=niz[j];
    *ULAZ=(*ULAZ+1)%5;
    SemOp(pisi,1);
    SemOp(prazan,1);
    sleep(1);
}


 void potrosac(int br_proi){
    sleep(1);
    char poruka[50];
    int i=0, j=0;

    do{
        SemOp(prazan,-1);
        if (mesp->M[*IZLAZ]!='\0'){
            poruka[i]=mesp->M[*IZLAZ];
            printf("Potrosac <- %c\n",poruka[i]);
            *IZLAZ=(*IZLAZ+1)%5;
            i++;}
            else j++;

    SemOp(pun,1);
    sleep(1);
    }while(j<br_proi);
    sleep(1);
    printf("Primljeno je %s\n",poruka);
}


int main(int argc, char *argv[]){
    int i,k;
    SemGet(3);
    br_proi=argc;
    SemOp(pun,1);
    SemOp(pisi,1);

    sigset(SIGINT,brisi);
    sigset(SIGINT,SemRemove);

    ID=shmget(IPC_PRIVATE,sizeof(int)*120,0600);
    if(ID==-1) exit (1);

    ULAZ=(int *)shmat(ID,NULL,0);
    *ULAZ=0;
    IZLAZ=(int *)shmat(ID,NULL,0)+1;
    *IZLAZ=0;
    mesp=(MS *)shmat(ID,NULL,0)+2;


    for(i=1;i<br_proi;i++){
        switch(fork()){
            case -1:
                printf("Ne moze se stvoriti novi proces!\n");
                exit(1);
            case 0:
                proizvodac(i,argv[i]);
                exit(0);
                }
        sleep(1);}



    switch(fork()){
        case -1:
            printf("Ne moze se stvoriti novi proces!\n");
            exit(0);
        case 0:
            potrosac(br_proi);
            exit(0);
            }
    for (i=0;i<br_proi;i++)
          wait(NULL);
SemRemove();
brisi();
return 0;

}
