#include <stdio.h>
#include <malloc.h>

int Tank = 10000;

struct atom{
       int Anfang;
       int Block_Grose;
       char frei;
       struct atom *nachste;
}Struktur;

void Liste_durchlaufen(Struktur *Kopf){

     Struktur *p;

     int i = 1;

     for (p = Kopf; p != NULL; p = p->nachste){

         printf("%d: pocetak = %d, velicina = %d, oznaka = %c\n",i, p->Anfang, p->Block_Grose, p->frei);

         i++;

     }

     return;

}



void frei_okkupiert_erzahlen(Struktur *Kopf,int *Num_frei,int *Num_okkupiert){

     Struktur *p;

     *Num_frei = 0;

     *Num_okkupiert = 0;

     for (p = Kopf; p != NULL; p = p->nachste) {

         if((p->frei) == 's') (*Num_frei)++;

         else if((p->frei) == 'z') (*Num_okkupiert)++;

     }

     return;

}



int vergeben(Struktur **Kopfp, int default_Grose){

  Struktur *neu, *p;

  int min = Tank + 12;

  int Block_adresse;

  for (p = *Kopfp; p != NULL; p = p->nachste){

       if((p->Block_Grose >= default_Grose + 12) && (p->frei == 's') && (p->Block_Grose < min)) {

                min = p->Block_Grose;

                Block_adresse = p->Anfang;

       }



  }



  if(min == Tank + 12) return -1;

  else{

       for (p = *Kopfp; p != NULL; p = p->nachste) {

            if (p->Anfang == Block_adresse) break;

       }

       p->frei = 'z';

       int Rest;

       Rest = p->Block_Grose - default_Grose - 12;

       if (Rest >= 13){  // 12 okteta za zaglavlje + 1 oktet za slobodan prostor

             p->Block_Grose = default_Grose + 12;

             neu = (Struktur *) malloc(sizeof(Struktur));

             neu->Anfang = p->Anfang + p->Block_Grose;

             neu->Block_Grose = Rest;

             neu->frei = 's';



             if(*Kopfp == NULL || (*kopfp)->Anfang >= neu->Anfang){



             // Dodavanje na pocetak liste

                    neu->nachste = *Kopfp;

                    *Kopfp = neu;

             } else{



             // Dodavanje iza postojeceg elementa kad:

             // postojeÊi atom nema sljedeÊeg ili

             // element u sljedeÊem cvoru je veÊi ili jednak novome

             for (p = *Kopfp; p->nachste && (p->nachste)->Anfang < neu->Anfang; p = p->nachste);

             neu->nachste = p->nachste;

             p->nachste = neu;

             }

       }

       return Block_adresse;

  }

}



void erlassen(Struktur **Kopfp, int default_Adresse){

    Struktur *p,*r;

    for(p = *Kopfp; p != NULL; p = p->nachste){

            if (p->Anfang == default_Adresse) break;

    }

    p->frei = 's';



    //spajanje slobodnih blokova

    p = *Kopfp;

    while (p->nachste != NULL){

            if ((p->frei == 's') && (p->nachste->frei == 's')) {

                   p->Block_Grose = p->Block_Grose + p->nachste->Block_Grose;

                   r = p->nachste;

                   p->nachste = p->nachste->nachste;

                   free(r);

                   p = *Kopfp;

            }

            else p = p->nachste;

    }

    return;

}







int main(){



    Struktur start;

    start.Anfang = 0;

    start.Block_Grose = Tank;

    start.frei = 's';

    start.nachste = NULL;



    Struktur *Kopf;

    Kopf = &start;



    int Num_frei;

    int Num_okkupiert;

    char Auswahl;

    int start_adresse;

    int default_Grose;



    while(1){

            frei_okkupiert_erzahlen(Kopf,&Num_frei,&Num_okkupiert);

            printf("RS: broj blokova = %d, slobodni = %d, zauzeti = %d\n", Num_frei+Num_okkupiert, Num_frei, Num_okkupiert);

            Liste_durchlaufen(Kopf);

            printf("\n");



            printf("Unesite zahtjev (d-dodijeli, o-oslobodi, x-izlaz iz programa): ");

            scanf("%s", &Auswahl);

            printf("\n");



            if(Auswahl == 'x'){

                 break;

            }

            else if(Auswahl == 'o'){

                 printf("Unesi pocetnu adresu programa: ");

                 scanf("%d", &start_adrese);

                 printf("\n");

                 oslobodi(&Kopf, start_adrese);

                 printf("Oslobodjen je blok s adrese %d.\n", start_adrese);

                 printf("\n");

            }

            else if(Auswahl == 'd'){

                 printf("Unesi velicinu programa u oktetima: ");

                 scanf("%d", &default_Grose

                 printf("\n");

                 int zuruck_adresse;

                 zuruck_adresse = vergeben(&Kopf, default_Grose);

                 if (zuruck_adresse == -1) printf("U radnom spremniku nema dovoljno prostora!\n");

                 else printf("Dodijeljen blok na adresi %d.\n", zuruck_adresse);

                 printf("\n");

            }

    }

   return 0;

}
