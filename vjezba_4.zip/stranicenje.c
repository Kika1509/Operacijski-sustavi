#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <ctype.h>
#include <time.h>
#include <malloc.h>

typedef struct{
	int Seite;
    int neu;
} Struktur;

int Rahme_Nummer, Gesuchen_Nummer;
int *Gesuchen;
Struktur *Rahme;

void *Generator(){
	int i, n;
	Gesuchen=(int*) malloc(sizeof(int)*Gesuchen_Nummer);
    n=Gesuchen_Nummer;
	for(i=0;i<Gesuchen_Nummer;i++)
        Gesuchen[i]=(rand()%9)+1;

	do{
    sleep(1);
	for(i=0;i<Gesuchen_Nummer-1;i++)
        Gesuchen[i]=Gesuchen[i+1];
    Gesuchen[Gesuchen_Nummer-1]=(rand()%9)+1;
    if(n) n--;
    else Gesuchen_Nummer--;
    }while(Gesuchen_Nummer);
}


int optimal_Strategie (int z,int n){
	int i,j,k=0;
	int pom=0;
	int d=0;
	int austauschen=-1;
    int Gesuch=z;

	for(i=0; i<Rahme_Nummer; i++){
		if(Rahme[i].Seite==Gesuch){
			pom=1;
			break;
		}
		else if(Rahme[i].Seite==-1){
			austauschen=i;
			pom=1;
			d++;
			break;
		}
	}
	if(pom==0){
		for(i=0; i<d; i++){
			for(j=0;j<n;j++){
				if(Rahme[i].Seite==Gesuchen[j])
					k=1;
					continue;
			}
            if(k==0){
				austauschen=i;
				return austauschen;
				}k=0;
		}
		for(j=n-1; j>=0; j--){
			for(i=0;i<d;i++){
				if(Gesuchen[j]==Rahme[i].Seite){
					austauschen=i;
					break;}
			}
		}
	}
return austauschen;
}


void drucken(int z, int Treffer, int Nummer_z){
	int i;
	for(i=0; i<Gesuchen_Nummer; i++){
		printf("%d",Gesuchen[i]);
		if(i==Gesuchen_Nummer-1)
			printf(" ");
		else
			printf(",");
   	}
	for(i=2*Nummer_z-1; i<23; i++)
		printf(" ");
	printf("%d  ", z);
	for(i=0; i<Rahme_Nummer; i++){
		if(z==Rahme[i].Seite && Treffer==0)
           		printf("[%d] ",Rahme[i].Seite);
            else if(z==Rahme[i].Seite && Treffer==1)
                printf("(%d) ",Rahme[i].Seite);
                    else if(Rahme[i].Seite==-1)
                        printf(" -  ");
                            else
                                printf(" %d  ",Rahme[i].Seite);
   	}
	if(Treffer==1)
		printf(" #pogodak");
	printf("\n");
}


int main(int argc, char *argv[]){
	int i, Num=0;
	int Treffer, Austausch, n, m;

	srand((unsigned)time (NULL));

	Rahme_Nummer = atoi(argv[1]);
   	Gesuchen_Nummer = atoi(argv[2]);

   	n=m=Gesuchen_Nummer;

   	if (Rahme_Nummer<4 || Rahme_Nummer>10 || Gesuchen_Nummer<5 || Gesuchen_Nummer>20){
		printf("Krivi broj parametara!");
		exit(1);}
	printf("Zahtjevi");
	printf("\t\t#N ");

	for(i=0; i<Rahme_Nummer; i++)
		printf(" %d  ", i+1);
	printf("\n");
	printf("--------------------------------------------------------\n");

    pthread_t thr_id;

	if((pthread_create(&thr_id, NULL, Generator, NULL))!=0){
		printf("Ne mogu stvoriti dretvu");
		exit(1);
	}

	Rahme = (Struktur *) malloc(Rahme_Nummer*sizeof(Struktur));

	for(i=0; i<Rahme_Nummer; i++)
		Rahme[i].Seite = -1;

	while(1){
		sleep(1);
		Treffer=0;
		Austausch= optimal_Strategie(Gesuchen[0],n);
		Num++;
		if(Num>Gesuchen_Nummer+1) n--;
		if(Austausch!=-1)   Rahme[Austausch].Seite=Gesuchen[0];
            else Treffer=1;
		if(Gesuchen_Nummer)	drucken(Gesuchen[0],Treffer,m);
            else break;
    }
	pthread_join(thr_id, NULL);
return 0;
}
